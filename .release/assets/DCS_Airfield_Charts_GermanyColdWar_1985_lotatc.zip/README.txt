DCS Airfield Charts - LotAtc drawings - GERMANY COLD WAR - AC-V1.12.0

One LotAtc drawing layer per file, for every airfield and helicopter base charted in this theatre:
- <base>.json: the airfield plan - pavement outline, runways, runway designators and taxiway names;
- <base>_parking.json: the parking stands, named as in the DCS mission editor.
Helicopter bases have no plan file, only their parking stands.

Install, on the LotAtc server: copy the files you want into
Saved Games/DCS/Mods/services/LotAtc/userdb/drawings/blue/ (and/or red/). LotAtc loads them at start, one layer per file.
A controller can also load a single file from the Draw tab of the LotAtc client.

Positions are read from DCS World: the F10 map for the plan, the mission editor for the parking stands.
They match the game, not the real airfields. Not for real-world navigation.
Data: F10 map and DCS World files (Eagle Dynamics), via pydcs. Non-commercial use only.
Source: https://github.com/MirabelleBenou/dcs-airfield-charts
